﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DateDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Date d1 = new Date(15);
            Date d2 = new Date(25);
            Date d3 = d1 + d2;

            Console.WriteLine($"{d1} + {d2} = {d1 + d2}");
            Console.WriteLine($"{d2} - {d1} = {d2 - d1}");
        }
    }
    class Date
    {
        int days;
        public int Day {  get => days % 30; }
        public int Month { get => days / 30; }
        public int Year { get => days / 365; }
        public Date(int days) => this.days = days;
        public override string ToString() => $"{Day:d2}/{Month:d2}/{Year:d4}";

        public static Date operator +(Date lhs, Date rhs)
            => new Date(lhs.days + rhs.days);
        public static Date operator -(Date lhs, Date rhs)
            => new Date(lhs.days - rhs.days);
    }
}

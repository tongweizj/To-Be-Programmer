import express from 'express';
import cookieSession from 'cookie-session';
import bodyParser from 'body-parser';
import { initStorage, getUser } from './storage';

initStorage();

const app = express();

app.use(
  cookieSession({
    secret: 'mysecret',
  })
);

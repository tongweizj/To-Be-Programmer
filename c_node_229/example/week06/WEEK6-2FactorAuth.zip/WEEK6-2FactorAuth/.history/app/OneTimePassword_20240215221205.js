import React, { useCallback, useState } from 'react';
import { verifyOtp } from './api';
import Input from './Input';
 
export default function OneTimePassword({ enabled }) {
  const [verificationCode, setVerificationCode] = useState('');
  const [invalidCode, setInvalidCode] = useState(false);
 
  const handleSubmit = useCallback(
    async (e) => {
      e.preventDefault();
 
      const result = await verifyOtp(verificationCode);

import express from 'express';
import cookieSession from 'cookie-session';
import bodyParser from 'body-parser';
import { initStorage, getUser, setUser } from './storage';
import crypto from 'crypto';
import util from 'util';
import qrcode from 'qrcode';
import base32Encode from 'base32-encode';
import { verifyTOTP } from './otp';
 
initStorage();
 
const app = express();
 
app.use(
  cookieSession({
    secret: 'mysecret',
  })
);

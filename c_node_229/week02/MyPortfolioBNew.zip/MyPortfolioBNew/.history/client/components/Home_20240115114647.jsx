import B
export default function Home() {
     return <p>Hello World!</p>
     <img src={BBG} alt="profile" className="bbg">
     }
    
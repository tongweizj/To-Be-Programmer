const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
 
const commonConfig = {
  mode: 'development',
 
  module: {
    rules: [
      {
        test: /\.m?js$/,
        exclude: /node_modules/,

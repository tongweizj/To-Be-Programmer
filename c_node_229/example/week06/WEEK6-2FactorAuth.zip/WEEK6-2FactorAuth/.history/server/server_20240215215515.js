import express from 'express';
import cookieSession from 'cookie-session';
import bodyParser from 'body-parser';
import { initStorage, getUser, setUser } from './storage';
import crypto from 'crypto';
import util from 'util';
import qrcode from 'qrcode';
import base32Encode from 'base32-encode';
import { verifyTOTP } from './otp';
 
initStorage();
 
const app = express();
 
app.use(
  cookieSession({
    secret: 'mysecret',
  })
);
 
app.use(bodyParser.json());
 
app.use(express.static('build/public'));
 
// Restore user from session
app.use(function (req, res, next) {
  if (req.session.username) {
    req.user = getUser(req.session.username);
  }
  next();
});
 
app.get('/logout', (req, res) => {
  req.session = null;
  res.redirect('/');
});
 
app.post('/login', (req, res) => {
  let authenticatedUser;
 
  const { body } = req;
  if (body.username) {
    // try password login
    const user = getUser(body.username);
    if (user && user.password === body.password) {
      authenticatedUser = user;
      // create session
      req.session.username = body.username;
    }
  } else if (req.user) {
    // try session login
    authenticatedUser = req.user;
}
 
if (!authenticatedUser) {
  // no user found, destroy session and return unauthorized
  req.session = null;
  return res.status(401).end();
}
 
// strip password and mfaSecret from response
const { password, mfaSecret, ...response } = authenticatedUser;
res.json(response);
});
 
// Endpoints beyond this point must be authenticated
app.use(function (req, res, next) {
  if (!req.user) {
    return res.status(401).end();
  }
  next();
});
 
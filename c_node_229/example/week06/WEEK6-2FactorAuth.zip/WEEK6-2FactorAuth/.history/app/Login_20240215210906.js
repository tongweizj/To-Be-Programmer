import React, { useCallback, useState } from 'react';
import { login } from './api';
import Input from './Input';
 
export default function Login({ onLogin }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [invalidCredentials, setInvalidCredentials] = useState(false);
 
  const handleSubmit = useCallback(
    async (e) => {
      e.preventDefault();
 
      const res = await login(username, password);
 
      // For simplicity, we refresh the page after authenticating
      // and let app handle the flow
      if (res.user) return (window.location = '/');
);
}
  );
}


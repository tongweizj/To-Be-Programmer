import { isArray } from 'util';
 
const fs = require('fs');
 
const storagePath = './storage';
const usersPath = `${storagePath}/users.json`;
 
const initialUsers = {
  alan: {
    username: 'alan',
    password: '1',

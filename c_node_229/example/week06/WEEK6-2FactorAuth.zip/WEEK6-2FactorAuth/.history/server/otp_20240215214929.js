import crypto from 'crypto';
import base32Decode from 'base32-decode';
 
export function generateHOTP(secret, counter) {
  const decodedSecret = base32Decode(secret, 'RFC4648');
 
  const buffer = Buffer.alloc(8);
  for (let i = 0; i < 8; i++) {
    buffer[7 - i] = counter & 0xff;
    counter = counter >> 8;
  }


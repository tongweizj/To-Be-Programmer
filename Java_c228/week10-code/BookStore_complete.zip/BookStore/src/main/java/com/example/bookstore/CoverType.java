package com.example.bookstore;

public enum CoverType {
    PAPERBACK, HARDCOVER, KINDLE_EDITION
}

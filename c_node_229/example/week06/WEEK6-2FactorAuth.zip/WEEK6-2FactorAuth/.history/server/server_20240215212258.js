import express from 'express';
import cookieSession from 'cookie-session';
import bodyParser from 'body-parser';
import { initStorage, getUser } from './storage';

initStorage();

const app = express();

app.use(
  cookieSession({
    secret: 'mysecret',
  })
);
 app.use(bodyParser.json());
 
app.use(express.static('build/public'));
 
app.get('/logout', (req, res) => {
  req.session = null;
  res.redirect('/');
});

app.post('/login', (req, res) => {
  let authenticatedUser;

  const { body } = req;
  if (body.username) {

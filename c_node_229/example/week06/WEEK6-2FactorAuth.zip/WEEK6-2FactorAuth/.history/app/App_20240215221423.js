import React, { useCallback, useState } from 'react';
import Login from './Login';
import OneTimePassword from './OneTimePassword';
 
export default function App({ user }) {
  // user not logged in, show login form
  if (!user) return <Login />;
 
